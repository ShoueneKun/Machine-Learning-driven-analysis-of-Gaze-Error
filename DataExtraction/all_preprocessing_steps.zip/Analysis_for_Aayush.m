format long g

close all
clc

gaze_data = readtable('exports/gaze_positions.csv');
pupil_data = readtable('exports/pupil_positions.csv');
ProcessData = load('exports/ProcessData.mat');
ProcessData = ProcessData.ProcessData;
ETG = ProcessData.ETG;

T = gaze_data.timestamp;

dT = diff(T);

Fs_std = std(1./dT);
Fs_mean = mean(1./dT);

figure;
histogram(1./diff(T), 200)
xlabel('Sampling Rate (Hz)')
ylabel('Counts')
title(sprintf('SR. Mean = %.2d, STD = %.2d', Fs_mean, Fs_std))
grid on

figure;
stem(pupil_data.timestamp(1:100)/1000, pupil_data.id(1:100))
xlabel('Time (S)')

T_cam_left = pupil_data.timestamp(pupil_data.id == 0);
T_cam_right = pupil_data.timestamp(pupil_data.id == 1);

figure;
subplot(1, 2, 1)
histogram(1./diff(T_cam_left), 200)
xlabel('Sampling Rate (Hz)')
ylabel('Counts')
title('Left SR histogram')
grid on
subplot(1, 2, 2)
histogram(1./diff(T_cam_right), 200)
xlabel('Sampling Rate (Hz)')
ylabel('Counts')
title('Right SR histogram')
grid on

[az, el, ~] = cart2sph(-ETG.EIHvector(:, 1), ETG.EIHvector(:, 3), ETG.EIHvector(:,2));
[az_raw, el_raw, ~] = cart2sph(-ETG.EIHvector_raw(:, 1), ETG.EIHvector_raw(:, 3), ETG.EIHvector_raw(:,2));

Y = fftshift(abs(fft(az - mean(az))));
Y_raw = fftshift(abs(fft(az_raw - mean(az_raw))));

freq = (0:length(az_raw)-1)*(Fs_mean/length(az_raw));
freq = freq - max(freq)/2;

figure()
semilogy(freq, Y_raw); hold on
semilogy(freq, Y);

