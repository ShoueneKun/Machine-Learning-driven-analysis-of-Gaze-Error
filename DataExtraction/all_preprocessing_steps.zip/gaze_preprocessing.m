clear all
close all
clc

addpath(genpath('/home/rakshit/Documents/MATLAB/gaze-in-wild'))

%% Read data
Pupil_Data = readtable('exports/pupil_positions.csv');
Gaze_Data = readtable('exports/gaze_positions.csv', 'Format', [repmat('%f', 1, 5), '%s', repmat('%f', 1, 15)]);

%% Identify crappy samples
eye0_Idx = find(~Pupil_Data.id);
eye1_Idx = find(Pupil_Data.id);

t_eye0 = Pupil_Data.timestamp(eye0_Idx); t_eye1 = Pupil_Data.timestamp(eye1_Idx);
dia_eye0 = Pupil_Data.diameter_3d(eye0_Idx); dia_eye1 = Pupil_Data.diameter_3d(eye1_Idx);
conf_eye0 = Pupil_Data.confidence(eye0_Idx); conf_eye1 = Pupil_Data.confidence(eye1_Idx);
pupil_radius_eye0 = Pupil_Data.diameter_3d(eye0_Idx); pupil_radius_eye1 = Pupil_Data.diameter_3d(eye1_Idx);

locForFix_eye0 = isoutlier(dia_eye0, 'gesd', 'ThresholdFactor', 0.8, 'SamplePoints', t_eye0) | conf_eye0 <= 0.3;
locForFix_eye1 = isoutlier(dia_eye1, 'gesd', 'ThresholdFactor', 0.8, 'SamplePoints', t_eye1) | conf_eye1 <= 0.3;

% Time stamps in GazeData file
ETG_T = Gaze_Data.timestamp;
ETG_T = ETG_T - ETG_T(1);

% Find the nearest time stamp to fix in the 240Hz, GazeData signal
locForFix_eye0 = logical(interp1(t_eye0, double(locForFix_eye0), ETG_T, 'nearest', 'extrap'));
locForFix_eye1 = logical(interp1(t_eye1, double(locForFix_eye1), ETG_T, 'nearest', 'extrap'));

% EIH vector from Raw PL data
EIHvector_0 = [Gaze_Data.gaze_normal0_x, Gaze_Data.gaze_normal0_y, Gaze_Data.gaze_normal0_z];
EIHvector_1 = [Gaze_Data.gaze_normal1_x, Gaze_Data.gaze_normal1_y, Gaze_Data.gaze_normal1_z];

origEIHvector_0 = EIHvector_0;

%% Correct super crappy samples
temp_T = ETG_T;
loc_nan_zero_0 = isnan(EIHvector_0);
loc_nan_zero_0 = logical(sum(loc_nan_zero_0, 2)) | logical(sum(EIHvector_0 == 0, 2) == 3) | locForFix_eye0;
EIHvector_0(loc_nan_zero_0, :) = []; temp_T(loc_nan_zero_0) = []; 
EIHvector_0 = interp1(temp_T, EIHvector_0, ETG_T, 'pchip', 'extrap'); % Interpolate over bad samples ONLY
EIHvector_0(EIHvector_0 > 1) = 1; EIHvector_0(EIHvector_0 < -1) = -1;

temp_T = ETG_T;
loc_nan_zero_1 = isnan(EIHvector_1); 
loc_nan_zero_1 = logical(sum(loc_nan_zero_1, 2)) | logical(sum(EIHvector_1 == 0, 2) == 3) | locForFix_eye1;
EIHvector_1(loc_nan_zero_1, :) = []; temp_T(loc_nan_zero_1) = []; 
EIHvector_1 = interp1(temp_T, EIHvector_1, ETG_T, 'pchip', 'extrap'); % Interpolate over bad samples ONLY
EIHvector_1(EIHvector_1 > 1) = 1; EIHvector_1(EIHvector_1 < -1) = -1;

%% Linearize gaze data
% Remove unused variables from workspace to reduce confusion
ETG.EIHvector_0 = EIHvector_0; clear EIHvector_0;
ETG.EIHvector_1 = EIHvector_1; clear EIHvector_1;

% Make time stamps equally spaced - this step is important for LPW because
% LPW filter expects equally spaced signals
[ETG.EIHvector_0, ETG.T] = linearizeData(ETG_T, ETG.EIHvector_0, 'pchip');

% The variable ETG.EIHvector0/1 are subsequently used to calculate the 
% cyclopean gaze vector which is LPF filtered and used in GIW analysis and
% all machine learning experiments

%% Plot differences before upsampling but after preprocessing

figure()
plot(ETG_T, origEIHvector_0(:, 1)); hold on;
plot(ETG.T, ETG.EIHvector_0(:, 1))
xlabel('Time (S)')
legend('Original', 'Linearized+BadRemoved')


%% Upsample unfiltered data to 300Hz

SR = 300;
max_T = max(ETG.T);
min_T = min(ETG.T);
T = linspace(min_T, max_T, (max_T-min_T)*SR);

EIH_unfiltered_upsampled_0 = interp1(ETG.T, ETG.EIHvector_0, T, 'pchip');

%% Plot the effects of up-sampling

figure()
plot(ETG_T, origEIHvector_0(:, 1)); hold on;
plot(ETG.T, ETG.EIHvector_0(:, 1));
plot(T, EIH_unfiltered_upsampled_0(:, 1))
legend('Original', 'Linearized+BadRemoved', 'Unfiltered_After_UpSamp')
xlabel('Time (S)')